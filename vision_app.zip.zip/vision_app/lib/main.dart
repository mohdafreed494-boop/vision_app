import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

// Gemini API Key
const String geminiApiKey = "AQ.Ab8RN6IFWghggVeMNXigvws5kP5nEZMX9iCDBntj2-unNmou_Q";

// Live Google AdMob Ad Unit IDs
const String liveBannerAdUnitId = "ca-app-pub-7974913592249239/8746710869";
const String liveRewardedAdUnitId = "ca-app-pub-7974913592249239/8136336779";

class AppStrings {
  static const Map<String, Map<String, String>> values = {
    'English': {
      'scanner': 'Scanner',
      'history': 'History',
      'saved': 'Saved',
      'settings': 'Settings',
      'capture_title': 'Capture or Upload Any Image',
      'smart_mode': 'Smart Mode',
      'camera': 'Camera',
      'gallery': 'Gallery',
      'custom_query_hint': 'Speak or type your question...',
      'inspect_btn': 'Inspect with OmniLens',
      'analyzing': 'OmniLens Analyzing...',
      'pro_badge': 'PRO',
      'go_pro': 'GO PRO \$1.99',
      'analysis_title': 'Analysis & Solution',
      'follow_up_title': 'Follow-Up Chat (Ask more)',
      'follow_up_hint': 'Ask more details...',
      'no_history': 'No scans recorded yet.',
      'no_saved': 'No saved bookmarks yet.',
      'language': 'Language',
      'subscription': 'Subscription Plan',
      'contact': 'Contact Us & Support',
      'app_version': 'App Version',
      'free_scans_left': 'Free Scans Left',
      'unlimited': 'Unlimited Pro',
      'logout': 'Logout',
      'retry': 'Retry',
      'network_error': 'Connection Error. Check internet & retry.',
      'report_copied': 'Report copied for sharing!',
      'listening': 'Listening...',
    },
    'Hindi': {
      'scanner': 'स्कैनर',
      'history': 'इतिहास',
      'saved': 'सुरक्षित',
      'settings': 'सेटिंग्स',
      'capture_title': 'फोटो खींचें या गैलरी से चुनें',
      'smart_mode': 'स्मार्ट मोड',
      'camera': 'कैमरा',
      'gallery': 'गैलरी',
      'custom_query_hint': 'बोलें या अपना सवाल लिखें...',
      'inspect_btn': 'ऑमनीलेंस से जांचें',
      'analyzing': 'विश्लेषण जारी है...',
      'pro_badge': 'प्रो',
      'go_pro': 'प्रो खरीदें \$1.99',
      'analysis_title': 'विश्लेषण और समाधान',
      'follow_up_title': 'आगे सवाल पूछें (चैट करें)',
      'follow_up_hint': 'इस बारे में और पूछें...',
      'no_history': 'अभी तक कोई स्कैन रिकॉर्ड नहीं है।',
      'no_saved': 'कोई बुकमार्क सुरक्षित नहीं है।',
      'language': 'भाषा (Language)',
      'subscription': 'सदस्यता प्लान',
      'contact': 'संपर्क और सहायता',
      'app_version': 'ऐप संस्करण',
      'free_scans_left': 'मुफ्त स्कैन शेष',
      'unlimited': 'असीमित प्रो',
      'logout': 'लॉग आउट',
      'retry': 'दोबारा कोशिश करें',
      'network_error': 'इंटरनेट कनेक्शन जांचें और पुनः प्रयास करें।',
      'report_copied': 'रिपोर्ट कॉपी हो गई!',
      'listening': 'सुन रहे हैं...',
    },
    'Urdu': {
      'scanner': 'اسکینر',
      'history': 'تاریخچہ',
      'saved': 'محفوظ شدہ',
      'settings': 'سیٹنگز',
      'capture_title': 'تصویر کھینچیں یا منتخب کریں',
      'smart_mode': 'سمارٹ موڈ',
      'camera': 'کیمرہ',
      'gallery': 'گیلری',
      'custom_query_hint': 'بولیں یا اپنا سوال لکھیں...',
      'inspect_btn': 'اومنی لینس سے معائنہ کریں',
      'analyzing': 'تجزیہ جاری ہے...',
      'pro_badge': 'پرو',
      'go_pro': 'پرو خریدیں \$1.99',
      'analysis_title': 'تجزیہ اور حل',
      'follow_up_title': 'مزید سوالات پوچھیں',
      'follow_up_hint': 'اس تصویر کے بارے میں مزید پوچھیں...',
      'no_history': 'کوئی اسکین ریکارڈ موجود نہیں۔',
      'no_saved': 'کوئی محفوظ آئٹم نہیں۔',
      'language': 'زبان (Language)',
      'subscription': 'سبسکرپشن پلان',
      'contact': 'رابطہ اور مدد',
      'app_version': 'ایپ ورژن',
      'free_scans_left': 'باقی مفت اسکینز',
      'unlimited': 'لامحدود پرو',
      'logout': 'لاگ آؤٹ',
      'retry': 'دوبارہ کوشش کریں',
      'network_error': 'انٹرنیٹ کنکشن چیک کریں اور دوبارہ کوشش کریں۔',
      'report_copied': 'رپورٹ کاپی ہو گئی!',
      'listening': 'سن رہے ہیں...',
    },
  };

  static String get(String lang, String key) {
    return values[lang]?[key] ?? values['English']![key] ?? key;
  }
}

class ChatMessage {
  final String sender;
  final String text;
  final String time;

  ChatMessage({
    required this.sender,
    required this.text,
    required this.time,
  });
}

class ScanRecord {
  final String id;
  final String title;
  final String category;
  final String responseText;
  final String time;
  final Uint8List imageBytes;
  bool isBookmarked;

  ScanRecord({
    required this.id,
    required this.title,
    required this.category,
    required this.responseText,
    required this.time,
    required this.imageBytes,
    this.isBookmarked = false,
  });
}

class UserAccount {
  final String authMethod;
  final String identifier;
  final String displayName;

  UserAccount({
    required this.authMethod,
    required this.identifier,
    required this.displayName,
  });
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Google AdMob Initialize
  await MobileAds.instance.initialize();
  runApp(const OmniLensApp());
}

class OmniLensApp extends StatelessWidget {
  const OmniLensApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'OmniLens AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF2563EB),
          primary: const Color(0xFF2563EB),
        ),
        scaffoldBackgroundColor: const Color(0xFFF8FAFC),
        useMaterial3: true,
      ),
      home: const AuthGatekeeper(),
    );
  }
}

class AuthGatekeeper extends StatefulWidget {
  const AuthGatekeeper({super.key});

  @override
  State<AuthGatekeeper> createState() => _AuthGatekeeperState();
}

class _AuthGatekeeperState extends State<AuthGatekeeper> {
  UserAccount? _currentUser;
  final Map<String, int> _accountScanQuota = {};
  final Map<String, bool> _accountProStatus = {};

  void _handleLogin(UserAccount user) {
    setState(() {
      _currentUser = user;
      if (!_accountScanQuota.containsKey(user.identifier)) {
        _accountScanQuota[user.identifier] = 3;
        _accountProStatus[user.identifier] = false;
      }
    });
  }

  void _handleLogout() {
    setState(() {
      _currentUser = null;
    });
  }

  void _updateUserQuota(int remaining) {
    if (_currentUser != null) {
      setState(() {
        _accountScanQuota[_currentUser!.identifier] = remaining;
      });
    }
  }

  void _upgradeUserToPro() {
    if (_currentUser != null) {
      setState(() {
        _accountProStatus[_currentUser!.identifier] = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_currentUser == null) {
      return LoginScreen(onLoginSuccess: _handleLogin);
    }

    final int currentRemaining = _accountScanQuota[_currentUser!.identifier] ?? 3;
    final bool isPro = _accountProStatus[_currentUser!.identifier] ?? false;

    return MainNavigationScreen(
      currentUser: _currentUser!,
      remainingFreeScans: currentRemaining,
      isProUser: isPro,
      onQuotaUpdated: _updateUserQuota,
      onProUpgraded: _upgradeUserToPro,
      onLogout: _handleLogout,
    );
  }
}

class LoginScreen extends StatefulWidget {
  final Function(UserAccount) onLoginSuccess;

  const LoginScreen({super.key, required this.onLoginSuccess});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _otpController = TextEditingController();
  bool _isOtpSent = false;
  bool _isLoading = false;

  void _signInWithGoogle() {
    setState(() => _isLoading = true);
    Future.delayed(const Duration(milliseconds: 900), () {
      setState(() => _isLoading = false);
      widget.onLoginSuccess(
        UserAccount(
          authMethod: 'Google',
          identifier: 'user.omnilens@gmail.com',
          displayName: 'Google Verified User',
        ),
      );
    });
  }

  void _sendPhoneOtp() {
    final phone = _phoneController.text.trim();
    if (phone.length < 8) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid mobile number')),
      );
      return;
    }

    setState(() => _isLoading = true);
    Future.delayed(const Duration(milliseconds: 800), () {
      setState(() {
        _isLoading = false;
        _isOtpSent = true;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Demo OTP sent: 1234')),
      );
    });
  }

  void _verifyOtp() {
    final otp = _otpController.text.trim();
    if (otp == "1234" || otp.length == 4) {
      widget.onLoginSuccess(
        UserAccount(
          authMethod: 'Phone',
          identifier: _phoneController.text.trim(),
          displayName: 'User (${_phoneController.text.trim()})',
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Invalid OTP. Enter 1234.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(
                  width: 72,
                  height: 72,
                  decoration: BoxDecoration(
                    color: Colors.blue.shade50,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.remove_red_eye_rounded, size: 40, color: Color(0xFF2563EB)),
                ),
                const SizedBox(height: 16),
                const Text(
                  'OmniLens AI',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 6),
                Text(
                  'Sign in to secure your AI visual scanner quota.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
                ),
                const SizedBox(height: 32),
                OutlinedButton.icon(
                  onPressed: _isLoading ? null : _signInWithGoogle,
                  icon: const Icon(Icons.g_mobiledata_rounded, size: 28, color: Colors.red),
                  label: const Text(
                    'Continue with Google',
                    style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.bold, color: Colors.black87),
                  ),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 13),
                    side: BorderSide(color: Colors.grey.shade300),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(child: Divider(color: Colors.grey.shade300)),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12.0),
                      child: Text('OR MOBILE NUMBER', style: TextStyle(fontSize: 11, color: Colors.grey.shade500, fontWeight: FontWeight.bold)),
                    ),
                    Expanded(child: Divider(color: Colors.grey.shade300)),
                  ],
                ),
                const SizedBox(height: 20),
                if (!_isOtpSent) ...[
                  TextField(
                    controller: _phoneController,
                    keyboardType: TextInputType.phone,
                    decoration: InputDecoration(
                      labelText: 'Mobile Number',
                      hintText: '+971 50 123 4567 / +91 9876543210',
                      prefixIcon: const Icon(Icons.phone_android_rounded, color: Color(0xFF2563EB)),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                  const SizedBox(height: 14),
                  ElevatedButton(
                    onPressed: _isLoading ? null : _sendPhoneOtp,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF2563EB),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    child: _isLoading
                        ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                        : const Text('Send Verification Code (OTP)', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                  ),
                ] else ...[
                  TextField(
                    controller: _otpController,
                    keyboardType: TextInputType.number,
                    maxLength: 4,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 22, letterSpacing: 8, fontWeight: FontWeight.bold),
                    decoration: InputDecoration(
                      labelText: 'Enter 4-Digit OTP',
                      helperText: 'Enter 1234 for testing',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                  const SizedBox(height: 14),
                  ElevatedButton(
                    onPressed: _verifyOtp,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF16A34A),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    child: const Text('Verify & Enter App', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                  ),
                  TextButton(
                    onPressed: () => setState(() => _isOtpSent = false),
                    child: const Text('Change Number', style: TextStyle(color: Colors.grey)),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  final UserAccount currentUser;
  final int remainingFreeScans;
  final bool isProUser;
  final Function(int) onQuotaUpdated;
  final VoidCallback onProUpgraded;
  final VoidCallback onLogout;

  const MainNavigationScreen({
    super.key,
    required this.currentUser,
    required this.remainingFreeScans,
    required this.isProUser,
    required this.onQuotaUpdated,
    required this.onProUpgraded,
    required this.onLogout,
  });

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentTabIndex = 0;
  String currentLanguage = "English";
  final List<ScanRecord> _scanHistory = [];

  RewardedAd? _rewardedAd;
  bool _isRewardedAdLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadRewardedAd();
  }

  void _loadRewardedAd() {
    RewardedAd.load(
      adUnitId: liveRewardedAdUnitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _rewardedAd = ad;
          _isRewardedAdLoaded = true;
        },
        onAdFailedToLoad: (error) {
          _isRewardedAdLoaded = false;
          _rewardedAd = null;
        },
      ),
    );
  }

  void _showRewardedAd() {
    if (_rewardedAd != null && _isRewardedAdLoaded) {
      _rewardedAd!.fullScreenContentCallback = FullScreenContentCallback(
        onAdDismissedFullScreenContent: (ad) {
          ad.dispose();
          _loadRewardedAd();
        },
        onAdFailedToShowFullScreenContent: (ad, error) {
          ad.dispose();
          _loadRewardedAd();
        },
      );
      _rewardedAd!.show(
        onUserEarnedReward: (ad, reward) {
          _addRewardedScan();
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('🎉 +1 Free Scan credited!'),
              backgroundColor: Color(0xFF16A34A),
            ),
          );
        },
      );
    } else {
      // Fallback dialog if ad network takes time to load
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => const RewardedAdPlayerDialog(),
      ).then((rewardEarned) {
        if (rewardEarned == true) {
          _addRewardedScan();
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('🎉 +1 Free Scan credited!'),
              backgroundColor: Color(0xFF16A34A),
            ),
          );
        }
      });
      _loadRewardedAd();
    }
  }

  void _consumeScan() {
    if (!widget.isProUser && widget.remainingFreeScans > 0) {
      widget.onQuotaUpdated(widget.remainingFreeScans - 1);
    }
  }

  void _addRewardedScan() {
    widget.onQuotaUpdated(widget.remainingFreeScans + 1);
  }

  void _addScanRecord(ScanRecord record) {
    setState(() {
      _scanHistory.insert(0, record);
    });
  }

  void _toggleBookmark(String id) {
    setState(() {
      final index = _scanHistory.indexWhere((element) => element.id == id);
      if (index != -1) {
        _scanHistory[index].isBookmarked = !_scanHistory[index].isBookmarked;
      }
    });
  }

  void _deleteRecord(String id) {
    setState(() {
      _scanHistory.removeWhere((element) => element.id == id);
    });
  }

  void _showSubscriptionSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.workspace_premium, color: Colors.amber, size: 30),
                  SizedBox(width: 8),
                  Text(
                    'No Free Scans Left',
                    style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                'Account (${widget.currentUser.identifier}) has reached limit. Watch video ad or go Pro.',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 13, color: Colors.black87),
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.pop(ctx);
                  _showRewardedAd();
                },
                icon: const Icon(Icons.play_circle_filled, color: Colors.white),
                label: const Text('Watch Short Video (+1 Free Scan)'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF16A34A),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: () {
                  Navigator.pop(ctx);
                  _processRealPaymentDialog();
                },
                icon: const Icon(Icons.workspace_premium, color: Color(0xFF2563EB)),
                label: const Text('Upgrade to Pro (\$1.99 / Month Unlimited)'),
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: Color(0xFF2563EB), width: 1.5),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _processRealPaymentDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Payment Checkout'),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Select payment method for OmniLens Pro:'),
            SizedBox(height: 12),
            ListTile(
              leading: Icon(Icons.credit_card, color: Colors.blue),
              title: Text('Credit / Debit Card'),
              dense: true,
            ),
            ListTile(
              leading: Icon(Icons.account_balance_wallet, color: Colors.green),
              title: Text('Google Pay / Apple Pay'),
              dense: true,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              widget.onProUpgraded();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Payment verified! OmniLens Pro active.')),
              );
            },
            child: const Text('Pay \$1.99'),
          ),
        ],
      ),
    );
  }

  void _changeLanguage(String lang) {
    setState(() {
      currentLanguage = lang;
    });
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> screens = [
      ScannerHomeScreen(
        currentLanguage: currentLanguage,
        isProUser: widget.isProUser,
        remainingFreeScans: widget.remainingFreeScans,
        onScanUsed: _consumeScan,
        onUpgradeRequested: _showSubscriptionSheet,
        onScanSaved: _addScanRecord,
      ),
      HistoryScreen(
        currentLanguage: currentLanguage,
        history: _scanHistory,
        onToggleBookmark: _toggleBookmark,
        onDelete: _deleteRecord,
      ),
      SavedNotesScreen(
        currentLanguage: currentLanguage,
        savedItems: _scanHistory.where((item) => item.isBookmarked).toList(),
        onToggleBookmark: _toggleBookmark,
      ),
      SettingsScreen(
        currentUser: widget.currentUser,
        remainingScans: widget.remainingFreeScans,
        isProUser: widget.isProUser,
        onUpgrade: _showSubscriptionSheet,
        currentLanguage: currentLanguage,
        onLanguageSelected: _changeLanguage,
        onLogout: widget.onLogout,
      ),
    ];

    return Scaffold(
      body: screens[_currentTabIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentTabIndex,
        onDestinationSelected: (index) {
          setState(() {
            _currentTabIndex = index;
          });
        },
        backgroundColor: Colors.white,
        elevation: 3,
        destinations: [
          NavigationDestination(
            icon: const Icon(Icons.document_scanner_outlined),
            selectedIcon: const Icon(Icons.document_scanner, color: Color(0xFF2563EB)),
            label: AppStrings.get(currentLanguage, 'scanner'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.history_outlined),
            selectedIcon: const Icon(Icons.history, color: Color(0xFF2563EB)),
            label: AppStrings.get(currentLanguage, 'history'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.bookmark_border_outlined),
            selectedIcon: const Icon(Icons.bookmark, color: Color(0xFF2563EB)),
            label: AppStrings.get(currentLanguage, 'saved'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.settings_outlined),
            selectedIcon: const Icon(Icons.settings, color: Color(0xFF2563EB)),
            label: AppStrings.get(currentLanguage, 'settings'),
          ),
        ],
      ),
    );
  }
}

class RewardedAdPlayerDialog extends StatefulWidget {
  const RewardedAdPlayerDialog({super.key});

  @override
  State<RewardedAdPlayerDialog> createState() => _RewardedAdPlayerDialogState();
}

class _RewardedAdPlayerDialogState extends State<RewardedAdPlayerDialog> {
  int _secondsRemaining = 15;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_secondsRemaining > 1) {
        setState(() {
          _secondsRemaining--;
        });
      } else {
        _timer?.cancel();
        setState(() {
          _secondsRemaining = 0;
        });
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Container(
        padding: const EdgeInsets.all(20),
        height: 320,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.amber.shade100,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: const Text('Sponsored Video Ad', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
                ),
                Text(
                  _secondsRemaining > 0 ? 'Reward in: $_secondsRemaining s' : 'Reward Ready!',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Colors.blueGrey),
                ),
              ],
            ),
            const Spacer(),
            Container(
              height: 110,
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.blue.shade200),
              ),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.play_circle_fill, size: 45, color: Color(0xFF2563EB)),
                    const SizedBox(height: 8),
                    Text(
                      _secondsRemaining > 0 ? 'Watching Rewarded Video...' : 'Completed! Claim Reward',
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ],
                ),
              ),
            ),
            const Spacer(),
            if (_secondsRemaining > 0)
              const LinearProgressIndicator(color: Color(0xFF2563EB))
            else
              ElevatedButton.icon(
                onPressed: () => Navigator.pop(context, true),
                icon: const Icon(Icons.card_giftcard),
                label: const Text('Claim +1 Free Scan'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF16A34A),
                  foregroundColor: Colors.white,
                  minimumSize: const Size.fromHeight(45),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class ScannerHomeScreen extends StatefulWidget {
  final String currentLanguage;
  final bool isProUser;
  final int remainingFreeScans;
  final VoidCallback onScanUsed;
  final VoidCallback onUpgradeRequested;
  final Function(ScanRecord) onScanSaved;

  const ScannerHomeScreen({
    super.key,
    required this.currentLanguage,
    required this.isProUser,
    required this.remainingFreeScans,
    required this.onScanUsed,
    required this.onUpgradeRequested,
    required this.onScanSaved,
  });

  @override
  State<ScannerHomeScreen> createState() => _ScannerHomeScreenState();
}

class _ScannerHomeScreenState extends State<ScannerHomeScreen> {
  Uint8List? _selectedImageBytes;
  final ImagePicker _picker = ImagePicker();
  final TextEditingController _questionController = TextEditingController();
  final TextEditingController _followUpChatController = TextEditingController();

  String aiResponse = "Capture or select any item to get an instant AI breakdown.";
  bool isScanning = false;
  bool isFollowUpLoading = false;
  bool hasNetworkError = false;
  String selectedCategory = "General / Ask";

  bool isFlashlightOn = false;
  double currentZoomLevel = 1.0;
  bool isCropFocusActive = false;

  final List<ChatMessage> _followUpMessages = [];

  BannerAd? _bannerAd;
  bool _isBannerLoaded = false;

  // Speech-to-Text Controller
  final stt.SpeechToText _speech = stt.SpeechToText();
  bool _isListening = false;

  final Map<String, IconData> categories = {
    "General / Ask": Icons.search,
    "Food & Nutrition": Icons.restaurant,
    "Plants & Pets": Icons.yard_outlined,
    "Fix & Repair": Icons.build_outlined,
    "Translate Text": Icons.translate,
  };

  @override
  void initState() {
    super.initState();
    _loadLiveBannerAd();
  }

  void _loadLiveBannerAd() {
    _bannerAd = BannerAd(
      adUnitId: liveBannerAdUnitId,
      request: const AdRequest(),
      size: AdSize.banner,
      listener: BannerAdListener(
        onAdLoaded: (ad) {
          setState(() {
            _isBannerLoaded = true;
          });
        },
        onAdFailedToLoad: (ad, err) {
          ad.dispose();
          _isBannerLoaded = false;
        },
      ),
    )..load();
  }

  // Voice Mic Toggle Function
  Future<void> _toggleMicListening() async {
    if (_isListening) {
      await _speech.stop();
      setState(() => _isListening = false);
    } else {
      bool available = await _speech.initialize(
        onStatus: (status) {
          if (status == 'done' || status == 'notListening') {
            setState(() => _isListening = false);
          }
        },
        onError: (errorNotification) {
          setState(() => _isListening = false);
        },
      );

      if (available) {
        setState(() => _isListening = true);

        // Language locale setting
        String localeId = "en_US";
        if (widget.currentLanguage == "Hindi") {
          localeId = "hi_IN";
        } else if (widget.currentLanguage == "Urdu") {
          localeId = "ur_PK";
        }

        _speech.listen(
          localeId: localeId,
          onResult: (result) {
            setState(() {
              _questionController.text = result.recognizedWords;
            });
          },
        );
      } else {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Microphone permission or speech recognition not available')),
        );
      }
    }
  }

  @override
  void dispose() {
    _speech.stop();
    _bannerAd?.dispose();
    _questionController.dispose();
    _followUpChatController.dispose();
    super.dispose();
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(source: source);
      if (pickedFile != null) {
        final bytes = await pickedFile.readAsBytes();
        setState(() {
          _selectedImageBytes = bytes;
          _followUpMessages.clear();
          hasNetworkError = false;
          aiResponse = "Image loaded! Tap 'Inspect with OmniLens' below.";
        });
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to pick image: $e')),
      );
    }
  }

  void _clearScreen() {
    setState(() {
      _selectedImageBytes = null;
      _questionController.clear();
      _followUpChatController.clear();
      _followUpMessages.clear();
      currentZoomLevel = 1.0;
      isFlashlightOn = false;
      isCropFocusActive = false;
      hasNetworkError = false;
      aiResponse = "Capture or select any item to get an instant AI breakdown.";
    });
  }

  String _buildIntelligentPrompt(String userText) {
    String langInstruction = "Respond entirely in ${widget.currentLanguage}. Use native, natural script for ${widget.currentLanguage}.\n";
    String base = langInstruction + "You are OmniLens AI, an expert visual analyst. Speak in concise, clear format.\n";

    if (isCropFocusActive) {
      base += "[Note: User applied Center-Crop Focus. Prioritize central object].\n";
    }

    if (userText.isNotEmpty) {
      return base + "User Query: '$userText'. Inspect the visual image and deliver direct findings.";
    }

    switch (selectedCategory) {
      case "Food & Nutrition":
        return base +
            "Analyze food item in 3 clear sections:\n"
            "1. Dish / Food Identification\n"
            "2. Estimated Nutrition & Calories\n"
            "3. Ingredients & Health Insights.";
      case "Plants & Pets":
        return base +
            "Analyze plant or pet:\n"
            "1. Common Name / Breed\n"
            "2. Health State & Environment Needs\n"
            "3. Safety Check: Toxicity for household pets/humans.";
      case "Fix & Repair":
        return base +
            "Diagnose machine or tool:\n"
            "1. Problem Identification\n"
            "2. Required Tools to fix\n"
            "3. 3-Step DIY Troubleshooting guide.";
      case "Translate Text":
        return base +
            "Extract text from image:\n"
            "1. Recognized Text\n"
            "2. Translation & Summary.";
      default:
        return base +
            "Provide:\n"
            "1. What is this item?\n"
            "2. Key details and status\n"
            "3. Helpful recommendations.";
    }
  }

  void _shareAnalysis() {
    if (aiResponse.contains("Capture or select")) return;
    
    final formattedCard = """
━━━━━━━━━━━━━━━━━━━━━━━━━━━
       🔍 OMNILENS AI REPORT
━━━━━━━━━━━━━━━━━━━━━━━━━━━
📅 Date: ${DateTime.now().year}-${DateTime.now().month}-${DateTime.now().day}
🕒 Time: ${DateTime.now().hour}:${DateTime.now().minute.toString().padLeft(2, '0')}
🏷️ Category: $selectedCategory (${widget.currentLanguage})
━━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 AI INSPECTION FINDINGS:

$aiResponse

━━━━━━━━━━━━━━━━━━━━━━━━━━━
🛡️ Verified by OmniLens AI
━━━━━━━━━━━━━━━━━━━━━━━━━━━
""";

    Clipboard.setData(ClipboardData(text: formattedCard));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(AppStrings.get(widget.currentLanguage, 'report_copied')),
        backgroundColor: const Color(0xFF2563EB),
      ),
    );
  }

  Future<void> _sendFollowUpQuestion() async {
    final query = _followUpChatController.text.trim();
    if (query.isEmpty || _selectedImageBytes == null) return;

    _followUpChatController.clear();
    final timeNow = "${DateTime.now().hour}:${DateTime.now().minute.toString().padLeft(2, '0')}";

    setState(() {
      _followUpMessages.add(ChatMessage(sender: 'user', text: query, time: timeNow));
      isFollowUpLoading = true;
    });

    try {
      final base64Image = base64Encode(_selectedImageBytes!);
      final url = Uri.parse(
        'https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=$geminiApiKey',
      );

      final followUpPrompt = "Language: Speak entirely in ${widget.currentLanguage}.\n"
          "Context: Previous answer was:\n'$aiResponse'\n\n"
          "User follow-up: '$query'\n"
          "Give a direct, concise response in ${widget.currentLanguage}.";

      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          "contents": [
            {
              "parts": [
                {"text": followUpPrompt},
                {
                  "inline_data": {
                    "mime_type": "image/jpeg",
                    "data": base64Image,
                  }
                }
              ]
            }
          ]
        }),
      );

      if (!mounted) return;

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final replyText = data['candidates'][0]['content']['parts'][0]['text'] ?? "No reply.";
        setState(() {
          _followUpMessages.add(ChatMessage(sender: 'omnilens', text: replyText, time: timeNow));
          isFollowUpLoading = false;
        });
      } else {
        setState(() {
          _followUpMessages.add(ChatMessage(
            sender: 'omnilens',
            text: "Follow-up error [Code ${response.statusCode}].",
            time: timeNow,
          ));
          isFollowUpLoading = false;
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _followUpMessages.add(ChatMessage(
          sender: 'omnilens',
          text: "Network lost. Please retry.",
          time: timeNow,
        ));
        isFollowUpLoading = false;
      });
    }
  }

  Future<void> _analyzeWithGemini() async {
    if (_selectedImageBytes == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select or capture a photo first!')),
      );
      return;
    }

    if (!widget.isProUser && widget.remainingFreeScans <= 0) {
      widget.onUpgradeRequested();
      return;
    }

    setState(() {
      isScanning = true;
      hasNetworkError = false;
      _followUpMessages.clear();
      aiResponse = AppStrings.get(widget.currentLanguage, 'analyzing');
    });

    widget.onScanUsed();

    try {
      final base64Image = base64Encode(_selectedImageBytes!);
      final url = Uri.parse(
        'https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=$geminiApiKey',
      );

      final prompt = _buildIntelligentPrompt(_questionController.text.trim());

      final response = await http
          .post(
            url,
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              "contents": [
                {
                  "parts": [
                    {"text": prompt},
                    {
                      "inline_data": {
                        "mime_type": "image/jpeg",
                        "data": base64Image,
                      }
                    }
                  ]
                }
              ]
            }),
          )
          .timeout(const Duration(seconds: 18));

      if (!mounted) return;

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final resultText =
            data['candidates'][0]['content']['parts'][0]['text'] ?? "No response returned from AI.";

        final newId = DateTime.now().millisecondsSinceEpoch.toString();
        setState(() {
          aiResponse = resultText;
          isScanning = false;
          hasNetworkError = false;
        });

        widget.onScanSaved(
          ScanRecord(
            id: newId,
            title: _questionController.text.trim().isNotEmpty
                ? _questionController.text.trim()
                : "$selectedCategory Scan",
            category: selectedCategory,
            responseText: resultText,
            time: "${DateTime.now().hour}:${DateTime.now().minute.toString().padLeft(2, '0')}",
            imageBytes: _selectedImageBytes!,
          ),
        );
      } else {
        setState(() {
          aiResponse = "Server error [Code ${response.statusCode}].";
          isScanning = false;
          hasNetworkError = true;
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        hasNetworkError = true;
        isScanning = false;
        aiResponse = AppStrings.get(widget.currentLanguage, 'network_error');
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final lang = widget.currentLanguage;

    return Scaffold(
      appBar: AppBar(
        title: const Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.remove_red_eye_rounded, color: Color(0xFF2563EB)),
            SizedBox(width: 8),
            Text('OmniLens AI', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 19)),
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: ElevatedButton.icon(
              onPressed: widget.onUpgradeRequested,
              icon: const Icon(Icons.workspace_premium, size: 16),
              label: Text(widget.isProUser ? AppStrings.get(lang, 'pro_badge') : AppStrings.get(lang, 'go_pro')),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.amber.shade700,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                textStyle: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          IconButton(
            tooltip: 'Clear Screen',
            icon: const Icon(Icons.refresh_rounded),
            onPressed: _selectedImageBytes == null ? null : _clearScreen,
          ),
        ],
        backgroundColor: Colors.white,
        elevation: 0.5,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: categories.entries.map((entry) {
                  final isSelected = selectedCategory == entry.key;
                  return Padding(
                    padding: const EdgeInsets.only(right: 8.0),
                    child: FilterChip(
                      avatar: Icon(
                        entry.value,
                        size: 16,
                        color: isSelected ? Colors.white : const Color(0xFF2563EB),
                      ),
                      label: Text(entry.key),
                      selected: isSelected,
                      selectedColor: const Color(0xFF2563EB),
                      labelStyle: TextStyle(
                        color: isSelected ? Colors.white : Colors.black87,
                        fontWeight: FontWeight.w600,
                        fontSize: 12,
                      ),
                      onSelected: (val) {
                        if (val) setState(() => selectedCategory = entry.key);
                      },
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 12),

            Container(
              height: 240,
              decoration: BoxDecoration(
                color: isFlashlightOn ? Colors.white : Colors.black87,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: isFlashlightOn ? Colors.amber : Colors.blue.shade100,
                  width: isFlashlightOn ? 3 : 2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: isFlashlightOn ? Colors.amber.withOpacity(0.3) : Colors.black.withOpacity(0.04),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  )
                ],
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  if (_selectedImageBytes != null)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(14),
                      child: Transform.scale(
                        scale: currentZoomLevel,
                        child: Image.memory(
                          _selectedImageBytes!,
                          fit: BoxFit.contain,
                          width: double.infinity,
                        ),
                      ),
                    )
                  else
                    Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: Colors.blue.shade50,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.camera_alt_outlined,
                              size: 40,
                              color: Color(0xFF2563EB),
                            ),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            AppStrings.get(lang, 'capture_title'),
                            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '${AppStrings.get(lang, 'smart_mode')}: $selectedCategory',
                            style: const TextStyle(color: Color(0xFF93C5FD), fontSize: 12, fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                    ),

                  if (isCropFocusActive && _selectedImageBytes != null)
                    Container(
                      width: 170,
                      height: 170,
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.greenAccent, width: 2.5),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Align(
                        alignment: Alignment.topCenter,
                        child: Padding(
                          padding: EdgeInsets.all(4.0),
                          child: Text(
                            'CENTER CROP FOCUS',
                            style: TextStyle(
                              fontSize: 9.5,
                              color: Colors.greenAccent,
                              fontWeight: FontWeight.bold,
                              backgroundColor: Colors.black54,
                            ),
                          ),
                        ),
                      ),
                    ),

                  Positioned(
                    top: 8,
                    right: 8,
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.6),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: Icon(
                              isFlashlightOn ? Icons.flash_on : Icons.flash_off,
                              size: 18,
                              color: isFlashlightOn ? Colors.amber : Colors.white,
                            ),
                            tooltip: 'Flashlight Simulation',
                            onPressed: () {
                              setState(() {
                                isFlashlightOn = !isFlashlightOn;
                              });
                            },
                          ),
                          IconButton(
                            icon: Icon(
                              isCropFocusActive ? Icons.crop_free : Icons.crop,
                              size: 18,
                              color: isCropFocusActive ? Colors.greenAccent : Colors.white,
                            ),
                            tooltip: 'Crop Focus Frame',
                            onPressed: () {
                              setState(() {
                                isCropFocusActive = !isCropFocusActive;
                              });
                            },
                          ),
                          TextButton(
                            style: TextButton.styleFrom(
                              padding: const EdgeInsets.symmetric(horizontal: 8),
                              minimumSize: Size.zero,
                              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            ),
                            onPressed: () {
                              setState(() {
                                if (currentZoomLevel == 1.0) {
                                  currentZoomLevel = 1.5;
                                } else if (currentZoomLevel == 1.5) {
                                  currentZoomLevel = 2.0;
                                } else {
                                  currentZoomLevel = 1.0;
                                }
                              });
                            },
                            child: Text(
                              '${currentZoomLevel}x',
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12),
                            ),
                          ),
                          const SizedBox(width: 6),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),

            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => _pickImage(ImageSource.camera),
                    icon: const Icon(Icons.camera_alt),
                    label: Text(AppStrings.get(lang, 'camera')),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF2563EB),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => _pickImage(ImageSource.gallery),
                    icon: const Icon(Icons.photo_library),
                    label: Text(AppStrings.get(lang, 'gallery')),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: const Color(0xFF2563EB),
                      elevation: 0,
                      side: BorderSide(color: Colors.blue.shade200),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),

            // Question Input Bar With Voice-to-Text Mic
            TextField(
              controller: _questionController,
              decoration: InputDecoration(
                hintText: _isListening
                    ? AppStrings.get(lang, 'listening')
                    : AppStrings.get(lang, 'custom_query_hint'),
                hintStyle: TextStyle(
                  fontSize: 12.5,
                  color: _isListening ? Colors.redAccent : Colors.grey.shade500,
                  fontWeight: _isListening ? FontWeight.bold : FontWeight.normal,
                ),
                prefixIcon: const Icon(Icons.help_outline, size: 20, color: Color(0xFF2563EB)),
                suffixIcon: IconButton(
                  icon: Icon(
                    _isListening ? Icons.mic : Icons.mic_none,
                    color: _isListening ? Colors.redAccent : const Color(0xFF2563EB),
                    size: 24,
                  ),
                  tooltip: 'Voice Search',
                  onPressed: _toggleMicListening,
                ),
                filled: true,
                fillColor: _isListening ? Colors.red.shade50 : Colors.white,
                contentPadding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.blue.shade100),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(
                    color: _isListening ? Colors.redAccent : Colors.grey.shade300,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 10),

            ElevatedButton.icon(
              onPressed: isScanning ? null : _analyzeWithGemini,
              icon: isScanning
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                    )
                  : const Icon(Icons.auto_awesome),
              label: Text(
                isScanning
                    ? AppStrings.get(lang, 'analyzing')
                    : (widget.isProUser
                        ? '${AppStrings.get(lang, 'inspect_btn')} (${AppStrings.get(lang, 'unlimited')})'
                        : '${AppStrings.get(lang, 'inspect_btn')} (${widget.remainingFreeScans})'),
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: widget.remainingFreeScans == 0 && !widget.isProUser
                    ? Colors.orange.shade700
                    : const Color(0xFF16A34A),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 13),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 14),

            if (hasNetworkError) ...[
              Container(
                padding: const EdgeInsets.all(12),
                margin: const EdgeInsets.only(bottom: 12),
                decoration: BoxDecoration(
                  color: Colors.red.shade50,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.red.shade200),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.wifi_off_rounded, color: Colors.redAccent),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        AppStrings.get(lang, 'network_error'),
                        style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.bold, color: Colors.red),
                      ),
                    ),
                    ElevatedButton(
                      onPressed: _analyzeWithGemini,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.redAccent,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      ),
                      child: Text(AppStrings.get(lang, 'retry'), style: const TextStyle(fontSize: 12)),
                    ),
                  ],
                ),
              ),
            ],

            Card(
              elevation: 1,
              color: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.psychology, color: Color(0xFF2563EB)),
                            const SizedBox(width: 8),
                            Text(
                              '$selectedCategory - ${AppStrings.get(lang, 'analysis_title')}',
                              style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            IconButton(
                              icon: const Icon(Icons.share, size: 20, color: Color(0xFF16A34A)),
                              tooltip: 'Share',
                              onPressed: _shareAnalysis,
                            ),
                            IconButton(
                              icon: const Icon(Icons.copy_rounded, size: 19, color: Colors.grey),
                              tooltip: 'Copy',
                              onPressed: () {
                                Clipboard.setData(ClipboardData(text: aiResponse));
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text(AppStrings.get(lang, 'report_copied'))),
                                );
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                    const Divider(height: 14),
                    SelectableText(
                      aiResponse,
                      style: const TextStyle(fontSize: 13.5, height: 1.5, color: Colors.black87),
                    ),
                  ],
                ),
              ),
            ),

            if (!aiResponse.contains("Capture or select")) ...[
              const SizedBox(height: 16),
              Card(
                elevation: 1,
                color: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                child: Padding(
                  padding: const EdgeInsets.all(14.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.forum_outlined, size: 18, color: Color(0xFF2563EB)),
                          const SizedBox(width: 8),
                          Text(
                            AppStrings.get(lang, 'follow_up_title'),
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      if (_followUpMessages.isNotEmpty) ...[
                        ..._followUpMessages.map((msg) {
                          final isUser = msg.sender == 'user';
                          return Align(
                            alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                            child: Container(
                              margin: const EdgeInsets.symmetric(vertical: 4),
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              decoration: BoxDecoration(
                                color: isUser ? const Color(0xFF2563EB) : Colors.grey.shade100,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text(
                                msg.text,
                                style: TextStyle(
                                  fontSize: 12.5,
                                  color: isUser ? Colors.white : Colors.black87,
                                ),
                              ),
                            ),
                          );
                        }),
                        const SizedBox(height: 8),
                      ],
                      if (isFollowUpLoading)
                        const Padding(
                          padding: EdgeInsets.symmetric(vertical: 8.0),
                          child: Center(
                            child: SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            ),
                          ),
                        ),
                      Row(
                        children: [
                          Expanded(
                            child: TextField(
                              controller: _followUpChatController,
                              style: const TextStyle(fontSize: 13),
                              decoration: InputDecoration(
                                hintText: AppStrings.get(lang, 'follow_up_hint'),
                                hintStyle: TextStyle(fontSize: 12, color: Colors.grey.shade500),
                                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                              ),
                              onSubmitted: (_) => _sendFollowUpQuestion(),
                            ),
                          ),
                          const SizedBox(width: 8),
                          IconButton(
                            icon: const Icon(Icons.send_rounded, color: Color(0xFF2563EB)),
                            onPressed: _sendFollowUpQuestion,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],

            // Real AdMob Banner Display
            if (!widget.isProUser) ...[
              const SizedBox(height: 14),
              _isBannerLoaded && _bannerAd != null
                  ? Container(
                      alignment: Alignment.center,
                      width: _bannerAd!.size.width.toDouble(),
                      height: _bannerAd!.size.height.toDouble(),
                      child: AdWidget(ad: _bannerAd!),
                    )
                  : Container(
                      height: 50,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade100,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.ad_units, size: 16, color: Colors.grey),
                            const SizedBox(width: 6),
                            Text(
                              'AdMob Banner Connecting...',
                              style: TextStyle(fontSize: 11, color: Colors.grey.shade700),
                            ),
                          ],
                        ),
                      ),
                    ),
            ],
          ],
        ),
      ),
    );
  }
}

class HistoryScreen extends StatelessWidget {
  final String currentLanguage;
  final List<ScanRecord> history;
  final Function(String) onToggleBookmark;
  final Function(String) onDelete;

  const HistoryScreen({
    super.key,
    required this.currentLanguage,
    required this.history,
    required this.onToggleBookmark,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(AppStrings.get(currentLanguage, 'history')), backgroundColor: Colors.white),
      body: history.isEmpty
          ? Center(
              child: Text(AppStrings.get(currentLanguage, 'no_history'),
                  style: const TextStyle(color: Colors.grey)),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: history.length,
              itemBuilder: (ctx, index) {
                final item = history[index];
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: ListTile(
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.memory(item.imageBytes, width: 50, height: 50, fit: BoxFit.cover),
                    ),
                    title: Text(item.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                    subtitle: Text('${item.category} • ${item.time}', style: const TextStyle(fontSize: 12)),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(
                            item.isBookmarked ? Icons.bookmark : Icons.bookmark_border,
                            color: item.isBookmarked ? const Color(0xFF2563EB) : Colors.grey,
                          ),
                          onPressed: () => onToggleBookmark(item.id),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                          onPressed: () => onDelete(item.id),
                        ),
                      ],
                    ),
                    onTap: () {
                      showDialog(
                        context: context,
                        builder: (c) => AlertDialog(
                          title: Text(item.title),
                          content: SingleChildScrollView(child: Text(item.responseText)),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(c), child: const Text('Close'))
                          ],
                        ),
                      );
                    },
                  ),
                );
              },
            ),
    );
  }
}

class SavedNotesScreen extends StatelessWidget {
  final String currentLanguage;
  final List<ScanRecord> savedItems;
  final Function(String) onToggleBookmark;

  const SavedNotesScreen({
    super.key,
    required this.currentLanguage,
    required this.savedItems,
    required this.onToggleBookmark,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(AppStrings.get(currentLanguage, 'saved')), backgroundColor: Colors.white),
      body: savedItems.isEmpty
          ? Center(
              child: Text(AppStrings.get(currentLanguage, 'no_saved'),
                  style: const TextStyle(color: Colors.grey)),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: savedItems.length,
              itemBuilder: (ctx, index) {
                final item = savedItems[index];
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: ListTile(
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.memory(item.imageBytes, width: 50, height: 50, fit: BoxFit.cover),
                    ),
                    title: Text(item.title, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text(item.responseText, maxLines: 2, overflow: TextOverflow.ellipsis),
                    trailing: IconButton(
                      icon: const Icon(Icons.bookmark_remove, color: Colors.red),
                      onPressed: () => onToggleBookmark(item.id),
                    ),
                    onTap: () {
                      showDialog(
                        context: context,
                        builder: (c) => AlertDialog(
                          title: Text(item.title),
                          content: SingleChildScrollView(child: Text(item.responseText)),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(c), child: const Text('Close'))
                          ],
                        ),
                      );
                    },
                  ),
                );
              },
            ),
    );
  }
}

class SettingsScreen extends StatelessWidget {
  final UserAccount currentUser;
  final int remainingScans;
  final bool isProUser;
  final VoidCallback onUpgrade;
  final String currentLanguage;
  final ValueChanged<String> onLanguageSelected;
  final VoidCallback onLogout;

  const SettingsScreen({
    super.key,
    required this.currentUser,
    required this.remainingScans,
    required this.isProUser,
    required this.onUpgrade,
    required this.currentLanguage,
    required this.onLanguageSelected,
    required this.onLogout,
  });

  void _showLanguageDialog(BuildContext context) {
    final languages = [
      {"name": "English", "native": "English"},
      {"name": "Hindi", "native": "हिंदी"},
      {"name": "Urdu", "native": "اردو"},
    ];

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Select Language'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: languages.map((lang) {
            final isSelected = currentLanguage == lang["name"];
            return ListTile(
              title: Text(lang["native"]!),
              subtitle: Text(lang["name"]!),
              trailing: isSelected ? const Icon(Icons.check, color: Color(0xFF2563EB)) : null,
              onTap: () {
                onLanguageSelected(lang["name"]!);
                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Language switched to ${lang["name"]}')),
                );
              },
            );
          }).toList(),
        ),
      ),
    );
  }

  void _showContactDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Contact & Support'),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Need help with OmniLens? Reach out to us:'),
            SizedBox(height: 14),
            Row(
              children: [
                Icon(Icons.email, size: 20, color: Color(0xFF2563EB)),
                SizedBox(width: 10),
                Text('support@omnilens.ai', style: TextStyle(fontWeight: FontWeight.bold)),
              ],
            ),
            SizedBox(height: 10),
            Row(
              children: [
                Icon(Icons.chat, size: 20, color: Colors.green),
                SizedBox(width: 10),
                Text('WhatsApp: +971 50 123 4567', style: TextStyle(fontWeight: FontWeight.bold)),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(AppStrings.get(currentLanguage, 'settings')), backgroundColor: Colors.white),
      body: ListView(
        children: [
          Container(
            margin: const EdgeInsets.all(12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.blue.shade100),
            ),
            child: Row(
              children: [
                CircleAvatar(
                  backgroundColor: const Color(0xFF2563EB),
                  child: Icon(
                    currentUser.authMethod == 'Google' ? Icons.mail_outline : Icons.phone_android,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(currentUser.displayName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14.5)),
                      Text(
                        'Verified via ${currentUser.authMethod}',
                        style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        isProUser
                            ? 'Status: ${AppStrings.get(currentLanguage, 'unlimited')}'
                            : '${AppStrings.get(currentLanguage, 'free_scans_left')}: $remainingScans',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: isProUser ? Colors.green.shade700 : Colors.blue.shade800,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  tooltip: AppStrings.get(currentLanguage, 'logout'),
                  icon: const Icon(Icons.logout, color: Colors.redAccent),
                  onPressed: onLogout,
                ),
              ],
            ),
          ),
          ListTile(
            leading: const Icon(Icons.workspace_premium, color: Colors.amber),
            title: Text(AppStrings.get(currentLanguage, 'subscription')),
            subtitle: Text(isProUser ? 'OmniLens Pro Active' : 'Free Tier (\$1.99 / Month for Pro)'),
            trailing: isProUser
                ? const Text('ACTIVE', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold))
                : ElevatedButton(onPressed: onUpgrade, child: const Text('Upgrade')),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.language, color: Color(0xFF2563EB)),
            title: Text(AppStrings.get(currentLanguage, 'language')),
            subtitle: Text(currentLanguage),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _showLanguageDialog(context),
          ),
          ListTile(
            leading: const Icon(Icons.headset_mic_outlined, color: Colors.green),
            title: Text(AppStrings.get(currentLanguage, 'contact')),
            subtitle: const Text('Email & WhatsApp Assistance'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _showContactDialog(context),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.info_outline),
            title: Text(AppStrings.get(currentLanguage, 'app_version')),
            subtitle: const Text('1.0.0 (OmniLens AdMob + Voice)'),
          ),
        ],
      ),
    )
  }
}