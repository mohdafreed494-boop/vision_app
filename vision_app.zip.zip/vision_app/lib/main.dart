import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

// Gemini API Key
const String geminiApiKey = "AQ.Ab8RN6IFwghggVemNXigvws5kP5nEZWX91CDBntj2-unNmou_Q";

// Test Google AdMob Ad Unit IDs (Testing ke waqt real IDs block ho jati hain)
const String liveBannerAdUnitId = "ca-app-pub-3940256099942544/6300978111";
const String liveRewardedAdUnitId = "ca-app-pub-3940256099942544/5224354917";

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await MobileAds.instance.initialize();
  } catch (e) {
    debugPrint("AdMob Init Error: $e");
  }
  runApp(const OmniLensApp());
}

class OmniLensApp extends StatelessWidget {
  const OmniLensApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'OmniLens AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blueAccent),
        useMaterial3: true,
      ),
      home: const MainNavigationScreen(),
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentIndex = 0;
  
  // User Profile Data
  String userName = "Guest User";
  String userEmail = "Not Logged In";
  bool isLoggedIn = false;
  int freeScansLeft = 3;
  bool isPro = false;

  void updateUserProfile(String name, String email) {
    setState(() {
      userName = name;
      userEmail = email;
      isLoggedIn = true;
      freeScansLeft = 3;
    });
  }

  void activateProPlan(String planName) {
    setState(() {
      isPro = true;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('OmniLens Pro ($planName) Activated Successfully!')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      ScannerScreen(
        isLoggedIn: isLoggedIn,
        userEmail: userEmail,
        freeScansLeft: freeScansLeft,
        isPro: isPro,
        onScanUsed: () {
          if (!isPro && freeScansLeft > 0) {
            setState(() => freeScansLeft--);
          }
        },
        onRewardEarned: () {
          setState(() => freeScansLeft += 1);
        },
        onUpgradeRequested: () => _showUpgradeSheet(context),
        onLoginRequested: () => _showLoginDialog(context),
      ),
      const HistoryScreen(),
      const SavedScreen(),
      SettingsScreen(
        userName: userName,
        userEmail: userEmail,
        isLoggedIn: isLoggedIn,
        freeScansLeft: freeScansLeft,
        isPro: isPro,
        onLoginTap: () => _showLoginDialog(context),
        onUpgradeTap: () => _showUpgradeSheet(context),
      ),
    ];

    return Scaffold(
      body: screens[_currentIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (index) => setState(() => _currentIndex = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.document_scanner_outlined), selectedIcon: Icon(Icons.document_scanner), label: 'Scanner'),
          NavigationDestination(icon: Icon(Icons.history_outlined), selectedIcon: Icon(Icons.history), label: 'History'),
          NavigationDestination(icon: Icon(Icons.bookmark_outline), selectedIcon: Icon(Icons.bookmark), label: 'Saved'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }

  // --- Real User Login Dialog ---
  void _showLoginDialog(BuildContext context) {
    final nameController = TextEditingController();
    final contactController = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Row(
          children: [
            Icon(Icons.remove_red_eye_rounded, color: Colors.blueAccent),
            SizedBox(width: 8),
            Text('Sign In / Register', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Enter your real credentials to track your AI scanner quota.'),
            const SizedBox(height: 16),
            TextField(
              controller: nameController,
              decoration: InputDecoration(
                labelText: 'Full Name',
                prefixIcon: const Icon(Icons.person_outline),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: contactController,
              decoration: InputDecoration(
                labelText: 'Email or Mobile Number',
                prefixIcon: const Icon(Icons.contact_mail_outlined),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blueAccent,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            onPressed: () {
              if (nameController.text.trim().isNotEmpty && contactController.text.trim().isNotEmpty) {
                updateUserProfile(nameController.text.trim(), contactController.text.trim());
                Navigator.pop(ctx);
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Please enter both name and email/phone')),
                );
              }
            },
            child: const Text('Continue'),
          ),
        ],
      ),
    );
  }

  // --- Upgrade to Pro Bottom Sheet ---
  void _showUpgradeSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.stars_rounded, color: Colors.amber, size: 52),
            const SizedBox(height: 8),
            const Text('Upgrade to OmniLens Pro', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const Text('Unlimited scans, high-priority AI analysis & 0 ads', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
            const SizedBox(height: 24),

            // 1 Month
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: const BorderSide(color: Colors.blueAccent, width: 1.5)),
              child: ListTile(
                title: const Text('1 Month Unlimited', style: TextStyle(fontWeight: FontWeight.bold)),
                subtitle: const Text('Standard access'),
                trailing: const Text('\$1.99', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.blueAccent)),
                onTap: () {
                  Navigator.pop(ctx);
                  activateProPlan('1 Month');
                },
              ),
            ),
            const SizedBox(height: 12),

            // 3 Months
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: const BorderSide(color: Colors.orange, width: 1.5)),
              child: ListTile(
                title: const Text('3 Months Unlimited', style: TextStyle(fontWeight: FontWeight.bold)),
                subtitle: const Text('Popular choice'),
                trailing: const Text('\$4.99', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.orange)),
                onTap: () {
                  Navigator.pop(ctx);
                  activateProPlan('3 Months');
                },
              ),
            ),
            const SizedBox(height: 12),

            // 6 Months
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: const BorderSide(color: Colors.green, width: 1.5)),
              child: ListTile(
                title: const Text('6 Months Unlimited', style: TextStyle(fontWeight: FontWeight.bold)),
                subtitle: const Text('Best value deal'),
                trailing: const Text('\$7.99', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.green)),
                onTap: () {
                  Navigator.pop(ctx);
                  activateProPlan('6 Months');
                },
              ),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}

// ======================== SCANNER SCREEN ========================
class ScannerScreen extends StatefulWidget {
  final bool isLoggedIn;
  final String userEmail;
  final int freeScansLeft;
  final bool isPro;
  final VoidCallback onScanUsed;
  final VoidCallback onRewardEarned;
  final VoidCallback onUpgradeRequested;
  final VoidCallback onLoginRequested;

  const ScannerScreen({
    super.key,
    required this.isLoggedIn,
    required this.userEmail,
    required this.freeScansLeft,
    required this.isPro,
    required this.onScanUsed,
    required this.onRewardEarned,
    required this.onUpgradeRequested,
    required this.onLoginRequested,
  });

  @override
  State<ScannerScreen> createState() => _ScannerScreenState();
}

class _ScannerScreenState extends State<ScannerScreen> {
  File? _selectedImage;
  final TextEditingController _queryController = TextEditingController();
  String _analysisResult = "";
  bool _isLoading = false;
  String? _errorMessage;

  // AdMob
  BannerAd? _bannerAd;
  bool _isBannerLoaded = false;
  RewardedAd? _rewardedAd;

  // Speech
  final stt.SpeechToText _speech = stt.SpeechToText();
  bool _isListening = false;

  @override
  void initState() {
    super.initState();
    _loadBannerAd();
    _loadRewardedAd();
  }

  void _loadBannerAd() {
    _bannerAd = BannerAd(
      adUnitId: liveBannerAdUnitId,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) => setState(() => _isBannerLoaded = true),
        onAdFailedToLoad: (ad, err) {
          debugPrint('BannerAd failed: $err');
          ad.dispose();
        },
      ),
    )..load();
  }

  void _loadRewardedAd() {
    RewardedAd.load(
      adUnitId: liveRewardedAdUnitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) => _rewardedAd = ad,
        onAdFailedToLoad: (err) => debugPrint('RewardedAd failed: $err'),
      ),
    );
  }

  void _showRewardedAd() {
    if (_rewardedAd != null) {
      _rewardedAd!.show(onUserEarnedReward: (ad, reward) {
        widget.onRewardEarned();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('+1 Free Scan Added!')),
        );
        _loadRewardedAd();
      });
    } else {
      widget.onRewardEarned();
      _loadRewardedAd();
    }
  }

  Future<void> _pickImage(ImageSource source) async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: source, imageQuality: 75);
    if (pickedFile != null) {
      setState(() {
        _selectedImage = File(pickedFile.path);
        _errorMessage = null;
      });
    }
  }

  Future<void> _analyzeWithGemini() async {
    if (!widget.isPro && widget.freeScansLeft <= 0) {
      _showQuotaDialog();
      return;
    }

    if (_selectedImage == null) {
      setState(() => _errorMessage = "Please take a photo or select an image first.");
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _analysisResult = "";
    });

    try {
      final bytes = await _selectedImage!.readAsBytes();
      final base64Image = base64Encode(bytes);
      final promptText = _queryController.text.trim().isEmpty ? "Explain what is in this image clearly." : _queryController.text.trim();

      final url = Uri.parse("https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$geminiApiKey");

      final body = jsonEncode({
        "contents": [
          {
            "parts": [
              {"text": promptText},
              {
                "inline_data": {
                  "mime_type": "image/jpeg",
                  "data": base64Image
                }
              }
            ]
          }
        ]
      });

      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: body,
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final answer = data['candidates']?[0]?['content']?['parts']?[0]?['text'] ?? "No text description found.";
        setState(() {
          _analysisResult = answer;
        });
        widget.onScanUsed();
      } else {
        setState(() {
          _errorMessage = "Connection Error (${response.statusCode}). Check internet & retry.";
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = "Connection Error. Check internet & retry.";
      });
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _showQuotaDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('No Free Scans Left', style: TextStyle(fontWeight: FontWeight.bold)),
        content: Text('Account (${widget.userEmail}) has reached its limit. Watch a video ad or go Pro.'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              _showRewardedAd();
            },
            child: const Text('Watch Short Video (+1 Scan)'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.blueAccent, foregroundColor: Colors.white),
            onPressed: () {
              Navigator.pop(ctx);
              widget.onUpgradeRequested();
            },
            child: const Text('Upgrade to Pro'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _bannerAd?.dispose();
    _queryController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(Icons.remove_red_eye_rounded, color: Colors.blueAccent),
            SizedBox(width: 8),
            Text('OmniLens AI', style: TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
        actions: [
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.amber,
              foregroundColor: Colors.black,
              elevation: 0,
            ),
            onPressed: widget.onUpgradeRequested,
            icon: const Icon(Icons.star, size: 18),
            label: Text(widget.isPro ? 'PRO ACTIVE' : 'GO PRO \$1.99'),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Preview Image Box
            Container(
              height: 240,
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.grey[300]!),
              ),
              child: _selectedImage != null
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: Image.file(_selectedImage!, fit: BoxFit.cover, width: double.infinity),
                    )
                  : const Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.add_photo_alternate_outlined, size: 54, color: Colors.grey),
                          SizedBox(height: 8),
                          Text('Select or Capture Image to Inspect', style: TextStyle(color: Colors.grey)),
                        ],
                      ),
                    ),
            ),
            const SizedBox(height: 14),

            // Camera & Gallery Buttons
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      backgroundColor: Colors.blueAccent,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: () => _pickImage(ImageSource.camera),
                    icon: const Icon(Icons.camera_alt),
                    label: const Text('Camera'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: () => _pickImage(ImageSource.gallery),
                    icon: const Icon(Icons.photo_library),
                    label: const Text('Gallery'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),

            // Prompt Box
            TextField(
              controller: _queryController,
              decoration: InputDecoration(
                hintText: 'yeh kya hai...',
                prefixIcon: const Icon(Icons.help_outline),
                suffixIcon: IconButton(
                  icon: Icon(_isListening ? Icons.mic : Icons.mic_none, color: _isListening ? Colors.red : Colors.grey),
                  onPressed: () async {
                    if (!_isListening) {
                      bool available = await _speech.initialize();
                      if (available) {
                        setState(() => _isListening = true);
                        _speech.listen(onResult: (val) {
                          setState(() {
                            _queryController.text = val.recognizedWords;
                          });
                        });
                      }
                    } else {
                      setState(() => _isListening = false);
                      _speech.stop();
                    }
                  },
                ),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 14),

            // Inspect Button
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepOrange,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: _isLoading ? null : _analyzeWithGemini,
              icon: _isLoading
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.auto_awesome),
              label: Text(
                _isLoading ? 'Analyzing...' : 'Inspect with OmniLens (${widget.isPro ? "Unlimited" : widget.freeScansLeft})',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 14),

            // Error Display
            if (_errorMessage != null)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.red[50],
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.red[200]!),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.wifi_off, color: Colors.red),
                    const SizedBox(width: 10),
                    Expanded(child: Text(_errorMessage!, style: const TextStyle(color: Colors.red))),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
                      onPressed: _analyzeWithGemini,
                      child: const Text('Retry'),
                    ),
                  ],
                ),
              ),

            // Results Display
            if (_analysisResult.isNotEmpty) ...[
              const SizedBox(height: 14),
              Card(
                elevation: 1,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.psychology, color: Colors.blueAccent),
                          SizedBox(width: 8),
                          Text('Analysis & Solution', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                        ],
                      ),
                      const Divider(height: 24),
                      SelectableText(
                        _analysisResult,
                        style: const TextStyle(fontSize: 15, height: 1.4),
                      ),
                    ],
                  ),
                ),
              ),
            ],

            const SizedBox(height: 20),

            // AdMob Banner Container
            if (!widget.isPro)
              Container(
                height: 50,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(8),
                ),
                child: _isBannerLoaded && _bannerAd != null
                    ? AdWidget(ad: _bannerAd!)
                    : const Text('AdMob Banner Loading...', style: TextStyle(color: Colors.grey)),
              ),
          ],
        ),
      ),
    );
  }
}

// ======================== SETTINGS SCREEN ========================
class SettingsScreen extends StatelessWidget {
  final String userName;
  final String userEmail;
  final bool isLoggedIn;
  final int freeScansLeft;
  final bool isPro;
  final VoidCallback onLoginTap;
  final VoidCallback onUpgradeTap;

  const SettingsScreen({
    super.key,
    required this.userName,
    required this.userEmail,
    required this.isLoggedIn,
    required this.freeScansLeft,
    required this.isPro,
    required this.onLoginTap,
    required this.onUpgradeTap,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // User Profile Card
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            color: Colors.blue[50],
            child: ListTile(
              contentPadding: const EdgeInsets.all(16),
              leading: CircleAvatar(
                radius: 28,
                backgroundColor: Colors.blueAccent,
                child: Text(
                  userName.isNotEmpty ? userName[0].toUpperCase() : 'U',
                  style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
                ),
              ),
              title: Text(userName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
              subtitle: Text('$userEmail\nFree Scans: ${isPro ? "Unlimited" : freeScansLeft}'),
              trailing: IconButton(
                icon: Icon(isLoggedIn ? Icons.edit : Icons.login, color: Colors.blueAccent),
                onPressed: onLoginTap,
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Subscription Plan
          ListTile(
            leading: const Icon(Icons.workspace_premium, color: Colors.amber),
            title: const Text('Subscription Plan'),
            subtitle: Text(isPro ? 'Pro Active (Unlimited)' : 'Free Tier (\$1.99 / Month for Pro)'),
            trailing: ElevatedButton(
              onPressed: onUpgradeTap,
              child: const Text('Upgrade'),
            ),
          ),
          const Divider(),

          // Contact Us & Support
          ListTile(
            leading: const Icon(Icons.support_agent, color: Colors.green),
            title: const Text('Contact Us & Support'),
            subtitle: const Text('Email & WhatsApp Assistance'),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () {
              showModalBottomSheet(
                context: context,
                shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
                builder: (ctx) => Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Contact & Support Assistance', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 16),
                      ListTile(
                        leading: const Icon(Icons.email, color: Colors.blue),
                        title: const Text('Email Support'),
                        subtitle: const Text('ansarisuhel610@gmail.com'),
                      ),
                      ListTile(
                        leading: const Icon(Icons.phone, color: Colors.green),
                        title: const Text('WhatsApp / Phone Support'),
                        subtitle: const Text('+971 523867378'),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
          const Divider(),

          // Version
          const ListTile(
            leading: Icon(Icons.info_outline),
            title: Text('App Version'),
            subtitle: Text('1.0.0 (OmniLens AdMob + Gemini Voice)'),
          ),
        ],
      ),
    );
  }
}

// ======================== PLACEHOLDER SCREENS ========================
class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Scan History')),
      body: const Center(child: Text('No previous scans recorded yet.')),
    );
  }
}

class SavedScreen extends StatelessWidget {
  const SavedScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Saved Items')),
      body: const Center(child: Text('No bookmarked scans yet.')),
    );
  }
}